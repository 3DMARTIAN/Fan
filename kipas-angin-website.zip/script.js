let isOn = false;

function toggleFan() {
  const fan = document.querySelector('.fan');
  isOn = !isOn;
  if (isOn) {
    fan.classList.add('spin');
  } else {
    fan.classList.remove('spin');
  }
}
